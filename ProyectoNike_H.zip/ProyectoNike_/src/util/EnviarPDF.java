package util;

import jakarta.activation.DataHandler;
import jakarta.activation.DataSource;
import jakarta.activation.FileDataSource;

import jakarta.mail.*;
import jakarta.mail.internet.*;
import java.util.Properties;


public class EnviarPDF {

    private static final String USUARIO = "hectorbartol@gmail.com";
    private static final String PASSWORD = "sgxjhyfllesxdjdg";

    public static void enviarTicket(String emailDestino, String rutaPdf) throws Exception {

        Properties props = new Properties();
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");

        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(USUARIO, PASSWORD);
            }
        });

        Message mensaje = new MimeMessage(session);
        mensaje.setFrom(new InternetAddress(USUARIO));
        mensaje.setRecipients(
            Message.RecipientType.TO,
            InternetAddress.parse(emailDestino)
        );
        mensaje.setSubject("Ticket de compra");

        BodyPart texto = new MimeBodyPart();
        texto.setText("Adjunto encontrarás tu ticket en formato PDF.");

        BodyPart adjunto = new MimeBodyPart();
        DataSource source = new FileDataSource(rutaPdf);
        adjunto.setDataHandler(new DataHandler(source));
        adjunto.setFileName("ticket.pdf");

        Multipart multipart = new MimeMultipart();
        multipart.addBodyPart(texto);
        multipart.addBodyPart(adjunto);

        mensaje.setContent(multipart);
        session.setDebug(true);

        Transport.send(mensaje);
    }
}
