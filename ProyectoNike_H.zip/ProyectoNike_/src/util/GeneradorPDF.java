package util;

import java.io.File;
import java.io.IOException;
import org.apache.pdfbox.pdmodel.*;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.PDPageContentStream;

public class GeneradorPDF {

    public static String generarPedido(
            String email,
            String telefono,
            String nombre,
            String apellidos,
            String ciudad,
            String direccion,
            String numTarjeta,
            String titularTarjeta,
            String fechaExp,
            String ccv
    ) throws IOException {

        // Crear carpeta si no existe
        File carpeta = new File("pdf");
        if (!carpeta.exists()) {
            carpeta.mkdir();
        }

        String ruta = "pdf/ticket.pdf";

        PDDocument doc = new PDDocument();
        PDPage page = new PDPage(PDRectangle.A4);
        doc.addPage(page);

        PDPageContentStream content = new PDPageContentStream(doc, page);

        // ===== TÍTULO =====
        content.beginText();
        content.setFont(PDType1Font.HELVETICA_BOLD, 18);
        content.newLineAtOffset(50, 760);
        content.showText("RESUMEN DEL PEDIDO");
        content.endText();

        // ===== DATOS DE ENTREGA =====
        content.beginText();
        content.setFont(PDType1Font.HELVETICA_BOLD, 14);
        content.newLineAtOffset(50, 720);
        content.showText("Datos de entrega");
        content.endText();

        content.beginText();
        content.setFont(PDType1Font.HELVETICA, 12);
        content.newLineAtOffset(50, 690);
        content.showText("Nombre: " + nombre + " " + apellidos);
        content.newLineAtOffset(0, -18);
        content.showText("Email: " + email);
        content.newLineAtOffset(0, -18);
        content.showText("Teléfono: " + telefono);
        content.newLineAtOffset(0, -18);
        content.showText("Ciudad: " + ciudad);
        content.newLineAtOffset(0, -18);
        content.showText("Dirección: " + direccion);
        content.endText();

        // ===== DATOS DE PAGO =====
        content.beginText();
        content.setFont(PDType1Font.HELVETICA_BOLD, 14);
        content.newLineAtOffset(50, 560);
        content.showText("Datos de pago");
        content.endText();

        content.beginText();
        content.setFont(PDType1Font.HELVETICA, 12);
        content.newLineAtOffset(50, 530);
        content.showText("Número de tarjeta: " + ocultarTarjeta(numTarjeta));
        content.newLineAtOffset(0, -18);
        content.showText("Titular: " + titularTarjeta);
        content.newLineAtOffset(0, -18);
        content.showText("Fecha de expiración: " + fechaExp);
        content.newLineAtOffset(0, -18);
        content.showText("CCV: ***");
        content.endText();

        content.close();
        doc.save(ruta);
        doc.close();

        return ruta;
    }

    // Buena práctica de seguridad
    private static String ocultarTarjeta(String num) {
        if (num.length() < 4) return "****";
        return "**** **** **** " + num.substring(num.length() - 4);
    }
}
