package gui;

import util.EnviarPDF;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Image;
import java.util.regex.Pattern;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import util.GeneradorPDF;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */

/**
 *
 * @author Alumno
 */
public class PasarelaPago extends javax.swing.JDialog {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(PasarelaPago.class.getName());
    Zapatilla zapatilla;
    
    /**
     * Creates new form Tallas
     */
    public PasarelaPago(JDialog parent, boolean modal, Zapatilla zapatilla) {
        super(parent, modal);
        initComponents();
        setTitle("ZapaX - Pasarela de pago");
        this.zapatilla=zapatilla;
        
        cambiarFoto();
        setLocationRelativeTo(null);
        double precio=precioZapatillaFinal();
        lbl_precioTotal.setText(String.valueOf(precio)+"€");
        btn_pagoRealizado.setBackground(new Color(76, 175, 80));
        btn_pagoRealizado.setForeground(Color.WHITE);
        sincronizarNombreCompleto();
        sincronizarDireccion();
        txt_email.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { actualizarBoton(); }
            public void removeUpdate(DocumentEvent e) { actualizarBoton(); }
            public void changedUpdate(DocumentEvent e) { actualizarBoton(); }
        });
        txt_tlfn.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { actualizarBoton(); }
            public void removeUpdate(DocumentEvent e) { actualizarBoton(); }
            public void changedUpdate(DocumentEvent e) { actualizarBoton(); }
        });
        txt_nombre.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { actualizarBoton(); }
            public void removeUpdate(DocumentEvent e) { actualizarBoton(); }
            public void changedUpdate(DocumentEvent e) { actualizarBoton(); }
        });
        txt_apellidos.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { actualizarBoton(); }
            public void removeUpdate(DocumentEvent e) { actualizarBoton(); }
            public void changedUpdate(DocumentEvent e) { actualizarBoton(); }
        });
        txt_ciudad.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { actualizarBoton(); }
            public void removeUpdate(DocumentEvent e) { actualizarBoton(); }
            public void changedUpdate(DocumentEvent e) { actualizarBoton(); }
        });
        txt_direccion.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { actualizarBoton(); }
            public void removeUpdate(DocumentEvent e) { actualizarBoton(); }
            public void changedUpdate(DocumentEvent e) { actualizarBoton(); }
        });
        txt_numeroTarjeta.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { actualizarBoton(); }
            public void removeUpdate(DocumentEvent e) { actualizarBoton(); }
            public void changedUpdate(DocumentEvent e) { actualizarBoton(); }
        });
        txt_titularTarjeta.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { actualizarBoton(); }
            public void removeUpdate(DocumentEvent e) { actualizarBoton(); }
            public void changedUpdate(DocumentEvent e) { actualizarBoton(); }
        });
        txt_fechaExpiracion.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { actualizarBoton(); }
            public void removeUpdate(DocumentEvent e) { actualizarBoton(); }
            public void changedUpdate(DocumentEvent e) { actualizarBoton(); }
        });
        txt_ccv.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { actualizarBoton(); }
            public void removeUpdate(DocumentEvent e) { actualizarBoton(); }
            public void changedUpdate(DocumentEvent e) { actualizarBoton(); }
        });
        

        
        actualizarBoton();
    }
    
    private double sacarCordones(){
        String letra=String.valueOf(zapatilla.getColorCordones());
        String color="";
        double precio=0;
        switch(letra){
            case "B":
                color="Blanco";
                break;
            case "N":
                color="Negro";
                break;
            case "R":
                color="Rojo";
                precio=5;
                break;    
        }
        return precio;
    }
    
    private double sacarColorSecundario(){
        String letra=String.valueOf(zapatilla.getColorSecundario());
        String color="";
        double precio=0;
        switch(letra){
            case "B":
                color="Blanco";
                jp_izq.setBackground(Color.WHITE);
                ImageIcon img1=new ImageIcon(getClass().getResource("/media/retrocederNegroSinFondo.png"));
                Image imagenEscalada1=img1.getImage().getScaledInstance(64, 64, Image.SCALE_SMOOTH);
                lbl_retroceder.setIcon(new ImageIcon(imagenEscalada1));
                break;
            case "N":
                color="Negro";
                img1=new ImageIcon(getClass().getResource("/media/retocederBlancoSinFondo.png"));
                imagenEscalada1=img1.getImage().getScaledInstance(64, 64, Image.SCALE_SMOOTH);
                lbl_retroceder.setIcon(new ImageIcon(imagenEscalada1));
                jp_izq.setBackground(Color.BLACK);
                lbl_datosEntrega.setForeground(Color.WHITE);
                lbl_pago.setForeground(Color.WHITE);
                lbl_email.setForeground(Color.WHITE);
                lbl_tlfn.setForeground(Color.WHITE);
                lbl_nombre.setForeground(Color.WHITE);
                lbl_apellidos.setForeground(Color.WHITE);
                lbl_ciudad.setForeground(Color.WHITE);
                lbl_direccion.setForeground(Color.WHITE);
                lbl_numTarjeta.setForeground(Color.WHITE);
                lbl_titular.setForeground(Color.WHITE);
                lbl_fechaExp.setForeground(Color.WHITE);
                lbl_ccv.setForeground(Color.WHITE);
                break;
            case "A":
                color="Azul";
                jp_izq.setBackground(Color.BLUE);
                img1=new ImageIcon(getClass().getResource("/media/retocederBlancoSinFondo.png"));
                imagenEscalada1=img1.getImage().getScaledInstance(64, 64, Image.SCALE_SMOOTH);
                lbl_retroceder.setIcon(new ImageIcon(imagenEscalada1));
                precio=10;
                lbl_datosEntrega.setForeground(Color.WHITE);
                lbl_pago.setForeground(Color.WHITE);
                lbl_email.setForeground(Color.WHITE);
                lbl_tlfn.setForeground(Color.WHITE);
                lbl_nombre.setForeground(Color.WHITE);
                lbl_apellidos.setForeground(Color.WHITE);
                lbl_ciudad.setForeground(Color.WHITE);
                lbl_direccion.setForeground(Color.WHITE);
                lbl_numTarjeta.setForeground(Color.WHITE);
                lbl_titular.setForeground(Color.WHITE);
                lbl_fechaExp.setForeground(Color.WHITE);
                lbl_ccv.setForeground(Color.WHITE);
                break;
            case "R":
                color="Rojo";
                img1=new ImageIcon(getClass().getResource("/media/retrocederNegroSinFondo.png"));
                imagenEscalada1=img1.getImage().getScaledInstance(64, 64, Image.SCALE_SMOOTH);
                lbl_retroceder.setIcon(new ImageIcon(imagenEscalada1));
                jp_izq.setBackground(Color.RED);
                precio=15;
                break;    
        }
        return precio;
    }
    
    public String getEmail() {
        return txt_email.getText().trim();
    }
    
    private double precioZapatillaFinal(){
        double precio=zapatilla.getPrecio();
        precio+=sacarColorSecundario();
        precio+=sacarCordones();
        return precio;
    }
    
    private boolean validarEmail() {
        boolean valido = true;
        String email = txt_email.getText().trim();

        if (!Pattern.matches("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$", email)) {
            txt_email.requestFocus();
            txt_email.selectAll();
            valido = false;
            return valido;
        }
        return valido;
    }
    private boolean emailVacio(){
        boolean vacio=true;
        if(!txt_email.getText().isEmpty()){
            vacio=false;
        }
        return vacio;
    }

    private boolean validarTelefono() {
        boolean valido = true;
        String telefono = txt_tlfn.getText().trim();

        if (!telefono.matches("^\\+?[0-9]{7,15}$")) {
            txt_tlfn.requestFocus();
            txt_tlfn.selectAll();
            valido = false;
            return valido;
        }
        return valido;
    }
    private boolean telefonoVacio() {
        boolean vacio = true;
        if (!txt_tlfn.getText().trim().isEmpty()) {
            vacio = false;
        }
    return vacio;
    }

    private boolean validarNombre() {
        boolean valido = true;
        String nombre = txt_nombre.getText().trim();

        if (!nombre.matches("^[A-Za-zÁÉÍÓÚáéíóúÑñ\\s]{2,50}$")) {
            txt_nombre.requestFocus();
            txt_nombre.selectAll();
            valido = false;
            return valido;
        }
        return valido;
    }
    private boolean nombreVacio() {
        boolean vacio = true;
        if (!txt_nombre.getText().trim().isEmpty()) {
            vacio = false;
        }
        return vacio;
    }

    private boolean validarApellidos() {
        boolean valido = true;
        String apellidos = txt_apellidos.getText().trim();

        if (!apellidos.matches("^[A-Za-zÁÉÍÓÚáéíóúÑñ\\s]{2,80}$")) {
            txt_apellidos.requestFocus();
            txt_apellidos.selectAll();
            valido = false;
            return valido;
        }
        return valido;
    }
    private boolean apellidosVacio() {
        boolean vacio = true;
        if (!txt_apellidos.getText().trim().isEmpty()) {
            vacio = false;
        }
        return vacio;
    }

    private boolean validarCiudad() {
        boolean valido = true;
        String ciudad = txt_ciudad.getText().trim();

        if (!ciudad.matches("^[A-Za-zÁÉÍÓÚáéíóúÑñ\\s]{2,60}$")) {
            txt_ciudad.requestFocus();
            txt_ciudad.selectAll();
            valido = false;
            return valido;
        }
        return valido;
    }
    private boolean ciudadVacio() {
        boolean vacio = true;
        if (!txt_ciudad.getText().trim().isEmpty()) {
            vacio = false;
        }
        return vacio;
    }

    private boolean validarDireccion() {
        boolean valido = true;
        String direccion = txt_direccion.getText().trim();

        if (!direccion.matches("^[A-Za-z0-9ÁÉÍÓÚáéíóúÑñ\\s#.,-]{5,120}$")) {
            txt_direccion.requestFocus();
            txt_direccion.selectAll();
            valido = false;
            return valido;
        }
        return valido;
    }
    private boolean direccionVacio() {
        boolean vacio = true;
        if (!txt_direccion.getText().trim().isEmpty()) {
            vacio = false;
        }
        return vacio;
    }

    private boolean validarNumeroTarjeta() {
        boolean valido = true;
        String tarjeta = txt_numeroTarjeta.getText().trim();

        if (!tarjeta.matches("^\\d{16}$")) {
            txt_numeroTarjeta.requestFocus();
            txt_numeroTarjeta.selectAll();
            valido = false;
            return valido;
        }
        return valido;
    }
    private boolean numeroTarjetaVacio() {
        boolean vacio = true;
        if (!txt_numeroTarjeta.getText().trim().isEmpty()) {
            vacio = false;
        }
        return vacio;
    }

    private boolean validarTitularTarjeta() {
        boolean valido = true;
        String titular = txt_titularTarjeta.getText().trim();

        if (!titular.matches("^[A-Za-zÁÉÍÓÚáéíóúÑñ\\s]{5,100}$")) {
            txt_titularTarjeta.requestFocus();
            txt_titularTarjeta.selectAll();
            valido = false;
            return valido;
        }
        return valido;
    }
    private boolean titularTarjetaVacio() {
        boolean vacio = true;
        if (!txt_titularTarjeta.getText().trim().isEmpty()) {
            vacio = false;
        }
        return vacio;
    }

    private boolean validarFechaExpiracion() {
        boolean valido = true;
        String fecha = txt_fechaExpiracion.getText().trim();

        if (!fecha.matches("^(0[1-9]|1[0-2])/\\d{2}$")) {
            txt_fechaExpiracion.requestFocus();
            txt_fechaExpiracion.selectAll();
            valido = false;
            return valido;
        }
        return valido;
    }
    private boolean fechaExpiracionVacio() {
        boolean vacio = true;
        if (!txt_fechaExpiracion.getText().trim().isEmpty()) {
            vacio = false;
        }
        return vacio;
    }

    private boolean validarCCV() {
        boolean valido = true;
        String ccv = txt_ccv.getText().trim();

        if (!ccv.matches("^\\d{3,4}$")) {
            txt_ccv.requestFocus();
            txt_ccv.selectAll();
            valido = false;
            return valido;
        }
        return valido;
    }
    private boolean ccvVacio() {
        boolean vacio = true;
        if (!txt_ccv.getText().trim().isEmpty()) {
            vacio = false;
        }
        return vacio;
    }
    
    private void sincronizarNombreCompleto() {

        javax.swing.event.DocumentListener escuchador = new javax.swing.event.DocumentListener() {
            private void actualizar() {
                String nombre = txt_nombre.getText().trim();
                String apellidos = txt_apellidos.getText().trim();

                lbl_nombreCompleto.setText(nombre + " " + apellidos);
            }

            @Override
            public void insertUpdate(javax.swing.event.DocumentEvent e) {
                actualizar();
            }

            @Override
            public void removeUpdate(javax.swing.event.DocumentEvent e) {
                actualizar();
            }

            @Override
            public void changedUpdate(javax.swing.event.DocumentEvent e) {
                actualizar();
            }
        };

        txt_nombre.getDocument().addDocumentListener(escuchador);
        txt_apellidos.getDocument().addDocumentListener(escuchador);
    }
    
    private void sincronizarDireccion() {

        txt_direccion.getDocument().addDocumentListener(
            new javax.swing.event.DocumentListener() {

                private void actualizar() {
                    lbl_DireccionCompleta.setText(txt_direccion.getText().trim()+", "+txt_ciudad.getText().trim());
                }

                @Override
                public void insertUpdate(javax.swing.event.DocumentEvent e) {
                    actualizar();
                }

                @Override
                public void removeUpdate(javax.swing.event.DocumentEvent e) {
                    actualizar();
                }

                @Override
                public void changedUpdate(javax.swing.event.DocumentEvent e) {
                    actualizar();
                }
            }
        );
    }
    
    private boolean todoRelleno() {
        boolean correcto=false;
        if(!emailVacio()
        && !telefonoVacio()
        && !nombreVacio()
        && !apellidosVacio()
        && !ciudadVacio()
        && !direccionVacio()
        && !numeroTarjetaVacio()
        && !titularTarjetaVacio()
        && !fechaExpiracionVacio()
        && !ccvVacio()){
            correcto=true;
        }
        return correcto;
    }
    
    private void actualizarBoton() {
        btn_pagoRealizado.setEnabled(todoRelleno());
    }   



    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btg_colores = new javax.swing.ButtonGroup();
        jp_izq = new javax.swing.JPanel();
        lbl_retroceder = new javax.swing.JLabel();
        lbl_datosEntrega = new javax.swing.JLabel();
        lbl_email = new javax.swing.JLabel();
        lbl_tlfn = new javax.swing.JLabel();
        lbl_nombre = new javax.swing.JLabel();
        lbl_apellidos = new javax.swing.JLabel();
        lbl_ciudad = new javax.swing.JLabel();
        lbl_direccion = new javax.swing.JLabel();
        txt_email = new javax.swing.JTextField();
        txt_tlfn = new javax.swing.JTextField();
        txt_nombre = new javax.swing.JTextField();
        txt_apellidos = new javax.swing.JTextField();
        txt_ciudad = new javax.swing.JTextField();
        txt_direccion = new javax.swing.JTextField();
        lbl_pago = new javax.swing.JLabel();
        lbl_numTarjeta = new javax.swing.JLabel();
        txt_numeroTarjeta = new javax.swing.JTextField();
        lbl_titular = new javax.swing.JLabel();
        txt_titularTarjeta = new javax.swing.JTextField();
        lbl_fechaExp = new javax.swing.JLabel();
        txt_fechaExpiracion = new javax.swing.JTextField();
        lbl_ccv = new javax.swing.JLabel();
        txt_ccv = new javax.swing.JTextField();
        btn_pagoRealizado = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        lbl_zapatilla = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        lbl_precioTotal = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        lbl_DireccionCompleta = new javax.swing.JLabel();
        lbl_nombreCompleto = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        lbl_pago1 = new javax.swing.JLabel();
        lbl_pago2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);

        jp_izq.setBackground(new java.awt.Color(246, 246, 246));

        lbl_retroceder.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lbl_retrocederMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lbl_retrocederMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lbl_retrocederMouseExited(evt);
            }
        });

        lbl_datosEntrega.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        lbl_datosEntrega.setText("Datos de entrega");

        lbl_email.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lbl_email.setText("Email*:");

        lbl_tlfn.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lbl_tlfn.setText("Telefono*:");

        lbl_nombre.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lbl_nombre.setText("Nombre*:");

        lbl_apellidos.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lbl_apellidos.setText("Apellidos*:");

        lbl_ciudad.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lbl_ciudad.setText("Ciudad*:");

        lbl_direccion.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lbl_direccion.setText("Direccion*:");

        txt_tlfn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_tlfnActionPerformed(evt);
            }
        });

        lbl_pago.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        lbl_pago.setText("Pago");

        lbl_numTarjeta.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lbl_numTarjeta.setText("Numero de la tarjeta*:");

        lbl_titular.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lbl_titular.setText("Titular de la tarjeta*:");

        lbl_fechaExp.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lbl_fechaExp.setText("Fecha de expiracion*:");

        txt_fechaExpiracion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_fechaExpiracionActionPerformed(evt);
            }
        });

        lbl_ccv.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lbl_ccv.setText("CCV*:");

        btn_pagoRealizado.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_pagoRealizado.setText("Realizar pago");
        btn_pagoRealizado.setEnabled(false);
        btn_pagoRealizado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_pagoRealizadoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jp_izqLayout = new javax.swing.GroupLayout(jp_izq);
        jp_izq.setLayout(jp_izqLayout);
        jp_izqLayout.setHorizontalGroup(
            jp_izqLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jp_izqLayout.createSequentialGroup()
                .addGroup(jp_izqLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jp_izqLayout.createSequentialGroup()
                        .addGap(66, 66, 66)
                        .addGroup(jp_izqLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jp_izqLayout.createSequentialGroup()
                                .addGroup(jp_izqLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jp_izqLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(txt_direccion, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 203, Short.MAX_VALUE)
                                        .addComponent(txt_ciudad, javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(txt_apellidos, javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(lbl_email, javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(lbl_tlfn, javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(txt_email, javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(txt_tlfn, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(lbl_apellidos)
                                    .addComponent(lbl_ciudad)
                                    .addComponent(lbl_direccion)
                                    .addComponent(txt_nombre, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lbl_datosEntrega))
                                .addGroup(jp_izqLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jp_izqLayout.createSequentialGroup()
                                        .addGap(68, 68, 68)
                                        .addGroup(jp_izqLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(lbl_fechaExp)
                                            .addComponent(txt_fechaExpiracion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(lbl_ccv)
                                            .addComponent(txt_ccv, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(jp_izqLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                                .addComponent(lbl_titular)
                                                .addComponent(lbl_pago)
                                                .addComponent(lbl_numTarjeta)
                                                .addComponent(txt_numeroTarjeta, javax.swing.GroupLayout.DEFAULT_SIZE, 193, Short.MAX_VALUE)
                                                .addComponent(txt_titularTarjeta))))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jp_izqLayout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btn_pagoRealizado, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addComponent(lbl_nombre)))
                    .addGroup(jp_izqLayout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addComponent(lbl_retroceder)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jp_izqLayout.setVerticalGroup(
            jp_izqLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jp_izqLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(lbl_retroceder, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addGroup(jp_izqLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jp_izqLayout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(lbl_pago))
                    .addComponent(lbl_datosEntrega, javax.swing.GroupLayout.Alignment.TRAILING))
                .addGap(18, 18, 18)
                .addGroup(jp_izqLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_email)
                    .addComponent(lbl_numTarjeta))
                .addGroup(jp_izqLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_email, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_numeroTarjeta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jp_izqLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_tlfn)
                    .addComponent(lbl_titular))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jp_izqLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_tlfn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_titularTarjeta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jp_izqLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_nombre)
                    .addComponent(lbl_fechaExp))
                .addGroup(jp_izqLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_nombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_fechaExpiracion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jp_izqLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbl_apellidos)
                    .addComponent(lbl_ccv))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jp_izqLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_apellidos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_ccv, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(lbl_ciudad)
                .addGroup(jp_izqLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jp_izqLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txt_ciudad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(lbl_direccion))
                    .addGroup(jp_izqLayout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(btn_pagoRealizado, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txt_direccion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(88, Short.MAX_VALUE))
        );

        lbl_zapatilla.setIcon(new javax.swing.ImageIcon(getClass().getResource("/media/img/zapatillaBlanca/B_N_B.png"))); // NOI18N

        jLabel18.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel18.setText("Precio total:");

        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel15.setText("Direccion:");

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel14.setText("Nombre completo:");

        lbl_pago1.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        lbl_pago1.setText("Zapatilla");

        lbl_pago2.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        lbl_pago2.setText("Resumen");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lbl_zapatilla, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(191, 191, 191)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel15)
                            .addComponent(jLabel18))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lbl_precioTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lbl_DireccionCompleta, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(152, 152, 152)
                        .addComponent(jLabel14)
                        .addGap(18, 18, 18)
                        .addComponent(lbl_nombreCompleto, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 28, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lbl_pago1)
                .addGap(141, 141, 141))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                    .addContainerGap(236, Short.MAX_VALUE)
                    .addComponent(lbl_pago2)
                    .addGap(141, 141, 141)))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbl_nombreCompleto, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel14, javax.swing.GroupLayout.Alignment.TRAILING))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel15, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lbl_DireccionCompleta, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel18)
                    .addComponent(lbl_precioTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(38, 38, 38)
                .addComponent(lbl_pago1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lbl_zapatilla, javax.swing.GroupLayout.PREFERRED_SIZE, 308, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(68, 68, 68)
                    .addComponent(lbl_pago2)
                    .addContainerGap(484, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jp_izq, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jp_izq, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void lbl_retrocederMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbl_retrocederMouseClicked
        anterior();
    }//GEN-LAST:event_lbl_retrocederMouseClicked

    private void lbl_retrocederMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbl_retrocederMouseEntered
        cursorMano();
    }//GEN-LAST:event_lbl_retrocederMouseEntered

    private void lbl_retrocederMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbl_retrocederMouseExited
        cursorNormal();
    }//GEN-LAST:event_lbl_retrocederMouseExited

    private void txt_tlfnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_tlfnActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_tlfnActionPerformed

    private void txt_fechaExpiracionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_fechaExpiracionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_fechaExpiracionActionPerformed

    private void btn_pagoRealizadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_pagoRealizadoActionPerformed
        boolean todoOk=true;
        if (!validarEmail()){
            JOptionPane.showMessageDialog(this, "Email inválido");
            todoOk=false;
        }
        if (!validarTelefono()){
            JOptionPane.showMessageDialog(this, "Teléfono inválido");
            todoOk=false;
        }
        if (!validarNombre()){
            JOptionPane.showMessageDialog(this, "Nombre inválido");
            todoOk=false;
        }
        if (!validarApellidos()){
            JOptionPane.showMessageDialog(this, "Apellidos inválidos");
            todoOk=false;
        }
        if (!validarCiudad()){
            JOptionPane.showMessageDialog(this, "Ciudad inválida");
            todoOk=false;
        }
        if (!validarDireccion()){
            JOptionPane.showMessageDialog(this, "Dirección inválida");
            todoOk=false;
        }
        if (!validarNumeroTarjeta()){
            JOptionPane.showMessageDialog(this, "La tarjeta debe tener 16 dígitos numéricos");
            todoOk=false;
        }
        if (!validarTitularTarjeta()){
            JOptionPane.showMessageDialog(this, "Titular de la tarjeta inválido");
            todoOk=false;
        }
        if (!validarFechaExpiracion()){
            JOptionPane.showMessageDialog(this, "Formato de fecha inválido (MM/AA)");
            todoOk=false;
        }
        if (!validarCCV()){
            JOptionPane.showMessageDialog(this, "CCV inválido");
            todoOk=false;
        }
    
        if (todoOk) {
            try{
                String rutaPdf=GeneradorPDF.generarPedido(
                    txt_email.getText(),
                    txt_tlfn.getText(),
                    txt_nombre.getText(),
                    txt_apellidos.getText(),
                    txt_ciudad.getText(),
                    txt_direccion.getText(),
                    txt_numeroTarjeta.getText(),
                    txt_titularTarjeta.getText(),
                    txt_fechaExpiracion.getText(),
                    txt_ccv.getText()
                );
                EnviarPDF.enviarTicket(getEmail(), rutaPdf);
                JOptionPane.showMessageDialog(this,"Pago realizado correctamente.\nTicket enviado a " + getEmail());
                this.dispose();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this,"Error al generar o enviar el ticket:\n" + e.getMessage());
                e.printStackTrace();
            }
        }
    }//GEN-LAST:event_btn_pagoRealizadoActionPerformed
    
    public void cambiarFoto(){
        if(zapatilla.getColorPrimario()=='B'){
            lbl_zapatilla.setIcon(new ImageIcon(getClass().getResource("/media/img/zapatillaBlanca/"
            + zapatilla.getColorPrimario()+ "_"
            + zapatilla.getColorSecundario() + "_"
            + zapatilla.getColorCordones() + ".png")));
        }else{
            lbl_zapatilla.setIcon(new ImageIcon(getClass().getResource("/media/img/zapatillaNegra/"
            + zapatilla.getColorPrimario()+ "_"
            + zapatilla.getColorSecundario() + "_"
            + zapatilla.getColorCordones() + ".png"))); 
        }
    }
    
    public void anterior () {
        Resumen resumen = new Resumen(this, true, this.zapatilla);
        this.setVisible(false);
        resumen.setVisible(true);
        this.dispose();
    }
    
    public void cursorMano () {
        this.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }
    
    public void cursorNormal () {
        this.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
    }
    
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup btg_colores;
    private javax.swing.JButton btn_pagoRealizado;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jp_izq;
    private javax.swing.JLabel lbl_DireccionCompleta;
    private javax.swing.JLabel lbl_apellidos;
    private javax.swing.JLabel lbl_ccv;
    private javax.swing.JLabel lbl_ciudad;
    private javax.swing.JLabel lbl_datosEntrega;
    private javax.swing.JLabel lbl_direccion;
    private javax.swing.JLabel lbl_email;
    private javax.swing.JLabel lbl_fechaExp;
    private javax.swing.JLabel lbl_nombre;
    private javax.swing.JLabel lbl_nombreCompleto;
    private javax.swing.JLabel lbl_numTarjeta;
    private javax.swing.JLabel lbl_pago;
    private javax.swing.JLabel lbl_pago1;
    private javax.swing.JLabel lbl_pago2;
    private javax.swing.JLabel lbl_precioTotal;
    private javax.swing.JLabel lbl_retroceder;
    private javax.swing.JLabel lbl_titular;
    private javax.swing.JLabel lbl_tlfn;
    private javax.swing.JLabel lbl_zapatilla;
    private javax.swing.JTextField txt_apellidos;
    private javax.swing.JTextField txt_ccv;
    private javax.swing.JTextField txt_ciudad;
    private javax.swing.JTextField txt_direccion;
    private javax.swing.JTextField txt_email;
    private javax.swing.JTextField txt_fechaExpiracion;
    private javax.swing.JTextField txt_nombre;
    private javax.swing.JTextField txt_numeroTarjeta;
    private javax.swing.JTextField txt_titularTarjeta;
    private javax.swing.JTextField txt_tlfn;
    // End of variables declaration//GEN-END:variables
}
