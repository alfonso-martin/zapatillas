/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gui;

import javax.swing.ImageIcon;

/**
 *
 * @author Alumno
 */
public class Zapatilla {
    
    private String modelo;
    private String sexo;
    private double talla;
    private double precio;
    private char colorPrimario;
    private char colorSecundario;
    private char colorCordones;

    public Zapatilla(String modelo, String sexo, double talla, double precio, char colorPrimario, char colorSecundario, char colorCordones) {
        this.modelo = modelo;
        this.sexo = sexo;
        this.talla = talla;
        this.precio = precio;
        this.colorPrimario = colorPrimario;
        this.colorSecundario = colorSecundario;
        this.colorCordones = colorCordones;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public double getTalla() {
        return talla;
    }

    public void setTalla(double talla) {
        this.talla = talla;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public char getColorPrimario() {
        return colorPrimario;
    }

    public void setColorPrimario(char colorPrimario) {
        this.colorPrimario = colorPrimario;
    }

    public char getColorSecundario() {
        return colorSecundario;
    }

    public void setColorSecundario(char colorSecundario) {
        this.colorSecundario = colorSecundario;
    }

    public char getColorCordones() {
        return colorCordones;
    }

    public void setColorCordones(char colorCordones) {
        this.colorCordones = colorCordones;
    }

    @Override
    public String toString() {
        return "Zapatilla{" + "modelo=" + modelo + ", sexo=" + sexo + ", talla=" + talla + ", precio=" + precio + ", colorPrimario=" + colorPrimario + ", colorSecundario=" + colorSecundario + ", colorCordones=" + colorCordones + '}';
    }    
}